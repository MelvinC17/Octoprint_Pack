                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2062472
Raspberry Pi 2 Stacking System by TafThorne is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

A stackable cradle for the Raspberry Pi 2 & Raspberry Pi 3.  Cannot call it a case as there are no sides and lid included.  Assembly post printing is straight forward, just stack more bodies with Pis in them.  If you want to link adjacent cradle bodies you will need to print two links.  

A friend wanted me to print [redogre](https://www.thingiverse.com/redogre/about)'s [Pi 2 stacking system](https://www.thingiverse.com/thing:694992) but with the link as part of the main file it would not fit on my Vector 3's build plate.  The solution was simple enough, split the model into two files: 

 - **RaspberryPiStack_Body_v3.stl** which is all you need to print to build a tower of [Raspberry Pi](https://www.raspberrypi.org/)s.  This features an updated body that has stronger attachments to its columns and some fixes to the geometry.  Hopefully these will help eliminate some slicer anomalies that were observed. 
 - **pi2stack_body_v2.stl** which is all you need to print to build a tower of [Raspberry Pi](https://www.raspberrypi.org/)s.  This features an updated body that has stronger attachments to its columns. 
 - **pi2stack_link.stl** which you can use to link neighbouring stacks of the body together

**Note** - The original pi2stack_body.stl file had weak links between the base and the columns that were easy to snap off.  I have created a more solid version; pi2stack_body_v2.stl that has strong connection.  

A larger resolution [image of the finished cradle](https://www.flickr.com/photos/tafthorne/32532671715) and one [with a Raspberry Pi 3 mounted](https://www.flickr.com/photos/tafthorne/32380118162) in it are available on my Flickr.  

# Print Settings

Printer: Vector 3
Rafts: Doesn't Matter
Supports: No

Notes: 
Do not use supports as these will block the stacking mount holes.  I printed mine at 0.10 mm with green PLA.  

# How I Designed This

## Splitting The File Into Separate Parts 

Took the original design, imported into Sketchup deleted the link and exported a new STL.  Then I released this process so I could export the link to its own file.  

After printing it and finding the towers broke away I checked the slice details again.  

![Alt text](https://cdn.thingiverse.com/assets/a9/dc/c6/8a/10/PiStackBodyIssue-MatterControle.PNG)
Notice the lack of connection between the column bases and the cradle 

## Better Connecting The Columns

I went into SketchUp, switched to X-ray mode and noticed some strange geometry around the towers.  Once I deleted some spare lines to just leave the external surface a newly exported STL would show a better looking corner.  

![Alt text](https://cdn.thingiverse.com/assets/a1/d4/0d/91/59/PiStackBodyIssue-RepairedColumnSlice.PNG)
Stronger connection between the column bases and the cradle 

Then all I had to do was repeat the process a few times to correct all four corners.  Now the slicer brings them all out as solid.  

I have attached my SketchUp files as RaspberryPiStacker.skp and RaspberryPiStacker.skb.